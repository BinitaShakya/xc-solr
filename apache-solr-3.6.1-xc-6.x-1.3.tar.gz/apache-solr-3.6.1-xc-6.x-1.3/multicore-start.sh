nohup sh multicore.sh &
